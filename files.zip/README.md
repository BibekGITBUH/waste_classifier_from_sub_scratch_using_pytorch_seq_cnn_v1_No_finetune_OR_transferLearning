# Smart Waste Image Classifier — Phase 1: Custom CNN

## Project structure
```
waste_classifier/
├── config.py           # paths, hyperparameters, class names
├── prepare_data.py     # splits datasets/final/<class> into train/val/test
├── dataset.py           # transforms, augmentation, dataloaders
├── models/
│   └── custom_cnn.py    # baseline CNN built from scratch
├── train.py             # training loop, early stopping, checkpointing
├── evaluate.py           # accuracy/precision/recall/F1/confusion matrix
├── checkpoints/          # saved model weights (.pt)
├── outputs/              # metrics, plots, training history
└── requirements.txt
```

## Setup
```bash
pip install -r requirements.txt
```

## Run order
1. Make sure your organized dataset from the download script lives at
   `datasets/final/<class_name>/*.jpg` with classes:
   `glass, metal, organic, paper, plastic`

2. Split into train/val/test (80/10/10):
   ```bash
   python prepare_data.py
   ```

3. (Optional) sanity-check the dataloaders:
   ```bash
   python dataset.py
   ```

4. Train the custom CNN:
   ```bash
   python train.py --model custom_cnn
   ```
   This saves the best checkpoint to `checkpoints/custom_cnn_best.pt` and
   training curves to `outputs/custom_cnn_history.json`.

5. Evaluate on the test set:
   ```bash
   python evaluate.py --model custom_cnn
   ```
   This prints accuracy/precision/recall/F1 per class, and saves:
   - `outputs/custom_cnn_classification_report.json`
   - `outputs/custom_cnn_confusion_matrix.png`

## What's next (Phase 2)
Once the custom CNN baseline is trained and evaluated, we'll add:
- `models/pretrained.py` with MobileNetV2 and ResNet50 (transfer learning,
  fine-tuned on this dataset)
- A comparison script/table (custom CNN vs MobileNetV2 vs ResNet50)
- A Streamlit demo app for interactive predictions

## Notes on class balance
If `prepare_data.py` prints very different image counts across classes,
consider using a weighted loss (`nn.CrossEntropyLoss(weight=...)`) or
weighted sampling — flag this to me once you've run it and I'll add that in.
